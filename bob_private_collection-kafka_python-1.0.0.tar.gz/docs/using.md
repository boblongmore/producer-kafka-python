# using kafka to produce messages that EDA can consue
